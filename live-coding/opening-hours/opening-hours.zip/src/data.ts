/*
 * {“dayOfWeek”: “openingHours”}
 *
 * dayOfWeek: monday | tuesday | wednesday | thursday| friday | saturday | sunday
 *
 * openingHours: an array of objects containing openinghoursEach object
 * consists of two keys:-Type: open | close-Value: HH:MM:SS (“10:00:00”)
 *
 * Notes:
 * The store can have multiple opened and closed times (Tuesday 9AM-1PM and 2PM-5PM)
 * If the store is closed then the array of opening hours is empty
 * The store might not be closed during the same day.
 * The store can be open on Sunday evening and close on Monday morning.
 */
export default {
  Monday: [
    { type: "open", value: "8: 00: 00" },
    { type: "open", value: "14: 00: 00" },
    { type: "close", value: "13: 00: 00" },
    { type: "close", value: "20: 00: 00" }
  ],
  Tuesday: [
    { type: "open", value: "8: 00: 00" },
    { type: "close", value: "17: 00: 00" }
  ],
  Wednesday: [],
  Thursday: [
    { type: "open", value: "8: 00: 00" },
    { type: "close", value: "17: 00: 00" }
  ],
  Friday: [{ type: "open", value: "17: 00: 00" }],
  Saturday: [
    { type: "close", value: "1: 00: 00" },
    { type: "open", value: "8: 00: 00" },
    { type: "close", value: "18: 00: 00" }
  ],
  Sunday: []
};
