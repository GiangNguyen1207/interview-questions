import "./styles.css";
import data from "./data";

export default function App() {
  // Your task is to write a web application that takes JSON opening hour data of a store
  // as an input and outputs ours as in the following design:

  return (
    <div className="App">
      <h1>Opening hours</h1>
      <hr />
      <p>Opening today 7-18</p>

      <table>
        <tbody>
          <tr>
            <td>Monday</td>
            <td>8-13 14-20</td>
          </tr>
          <tr>
            <td>Tuesday</td>
            <td>12-14</td>
          </tr>
          <tr>
            <td>Wednesday</td>
            <td>12-14</td>
          </tr>
          <tr>
            <td>Thursday</td>
            <td>12-14</td>
          </tr>
          <tr>
            <td>Friday</td>
            <td>12-14</td>
          </tr>
          <tr>
            <td>Saturday</td>
            <td>12-14</td>
          </tr>
          <tr>
            <td>Sunday</td>
            <td>Closed</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
